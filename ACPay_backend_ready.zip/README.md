# ACPay backend-ready demo

## Local / Termux
1. `npm install`
2. Create `.env` from `.env.example` and set a strong JWT_SECRET.
3. `npm start`
4. Open http://127.0.0.1:3000

## Render
Build command: `npm install`
Start command: `npm start`

This is a demo wallet/authentication app. It does NOT process real payments, USDT, deposits, or withdrawals. For production, use a persistent/managed database (for example PostgreSQL), HTTPS, secure secrets, rate limiting, audit logs, backups, and appropriate legal/compliance controls.
