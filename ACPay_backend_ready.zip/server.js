const express=require("express");
const path=require("path");
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
require("dotenv").config();
const app=express();
const db=new Database(process.env.DB_FILE||"acpay.db");
const SECRET=process.env.JWT_SECRET||"change-this-secret";
db.exec(`CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 balance REAL NOT NULL DEFAULT 750,
 created_at TEXT NOT NULL
)`);
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
app.post("/api/register",async(req,res)=>{
 const {username,password}=req.body||{};
 if(!username||!password||username.length<3||password.length<6)return res.status(400).json({error:"Username must be 3+ chars and password 6+ chars"});
 try{const hash=await bcrypt.hash(password,10);const now=new Date().toISOString();
 db.prepare("INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)").run(username,hash,now);
 res.json({ok:true});}catch(e){res.status(400).json({error:"Username already exists"})}
});
app.post("/api/login",async(req,res)=>{
 const {username,password}=req.body||{};const u=db.prepare("SELECT * FROM users WHERE username=?").get(username);
 if(!u||!(await bcrypt.compare(password||"",u.password_hash)))return res.status(401).json({error:"Invalid username or password"});
 res.json({token:jwt.sign({id:u.id},SECRET,{expiresIn:"7d"})});
});
function auth(req,res,next){try{const h=req.headers.authorization||"";const t=h.startsWith("Bearer ")?h.slice(7):"";req.uid=jwt.verify(t,SECRET).id;next()}catch(e){res.status(401).json({error:"Unauthorized"})}}
app.get("/api/me",auth,(req,res)=>{const u=db.prepare("SELECT id,username,balance,created_at FROM users WHERE id=?").get(req.uid);res.json({user:u})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
const port=process.env.PORT||3000;app.listen(port,()=>console.log("ACPay running on port "+port));